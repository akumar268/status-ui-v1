import { createSlice } from "@reduxjs/toolkit";

const interviewSlice = createSlice({
    name: 'InterviewApp',
    initialState: {
      loading: false,
    },
    reducers: {
    },
    extraReducers: {
    }
  })
  
export default interviewSlice;
