import { createSlice } from "@reduxjs/toolkit";

const candidateSlice = createSlice({
    name: 'CandidateApp',
    initialState: {
      loading: false,
    },
    reducers: {
    },
    extraReducers: {
    }
  })
  
  export default candidateSlice;
