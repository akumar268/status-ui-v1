import { createSlice } from "@reduxjs/toolkit";

const panelSlice = createSlice({
    name: 'PanelApp',
    initialState: {
      loading: false,
    },
    reducers: {
    },
    extraReducers: {
    }
  })
  
export default panelSlice;
