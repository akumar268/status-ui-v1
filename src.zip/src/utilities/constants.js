export const putUrl = "http://localhost:8005/pm/masterdata-management/candidate/update/";

export const post_url="http://localhost:8005/pm/masterdata-management/candidate/status"; //

export const get_Url = "http://localhost:8005/pm/masterdata-management/status?";

