import { React, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import addNewCandidateStatus from '../actions/add_new_candidate_status.js';
import {useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';




const CandidateForm = (props) => {

  const statusRef = useRef(null);

  let serverError=useSelector((state)=>state.serverError);
  let dispatcher = useDispatch();

  let navigate = useNavigate();
  const [form, setForm] = useState({})
  const [errors, setErrors] = useState({})


  const setField = (field, value) => {
    setForm({ ...form, [field]: value });
    if (!!errors[field]) {
      setErrors({ ...errors, [field]: null });
    }
  }

  const validateForm = () => {
    const {candidateStatus } = form;
    console.log(form)
    const newErrors = {}
    if (!candidateStatus || candidateStatus === '')
      newErrors.candidateStatus = 'Please enter the status';
    return newErrors;

  }


  const addCandidateStatus = (event) => {
    event.preventDefault();
    const formErrors = validateForm();
    console.log('formErrors', formErrors)
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
    }
    else {
      console.log(form);
      setErrors({});
      let newCandidateStatus = {"candidateStatus": statusRef.current.value };
      serverError=dispatcher(addNewCandidateStatus(newCandidateStatus));
    }
  }

  const cancelEdit = () => {
    navigate('/');
}



  return (
    <div className="container-wrap">
      <h2>Add Candidate Status Master</h2>
      <form data-testid='candidate-form'>
        <div className="row">
          <div className="col-md-1">
            <div className="form-group">
              <label className="fw-bolder" htmlFor="first">Status</label>
            </div>
          </div>
          <div className="col-md-5">
            <div className="form-group">
            <InputGroup hasValidation>
       <Form.Control   
              required  type="text"        
              placeholder="Enter status"      
              value={form.candidateStatus}       
              onChange={(event)=>setField('candidateStatus', event.target.value)}       
              isInvalid={!!errors.candidateStatus}
              ref={statusRef}
            />
            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
            <Form.Control.Feedback type="invalid"> {errors.candidateStatus}
              </Form.Control.Feedback>        
              </InputGroup>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-2">
            <button type="submit" className="btn btn-primary" onClick={addCandidateStatus}>Submit</button>
          </div>
          <div className="col-md-3">
            <button type="submit" className="btn btn-primary" onClick={cancelEdit}>Cancel</button>
          </div>
        </div>
      </form>
    </div>

  )
}


export default CandidateForm;


























