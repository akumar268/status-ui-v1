import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";
import { post_url } from "../utilities/constants";

const addNewCandidateStatus = createAsyncThunk(
  "addNewCandidate",
  async (newCandidateStatus, { getState, rejectWithValue }) => {
    console.log(
      "AddNewCandidate status called: newCandidateStatus - ",
      newCandidateStatus
    );
    let token =
      "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ2YXJzaGEiLCJleHAiOjE2NzE3NTIzMjAsImlhdCI6MTY3MTcxNjMyMH0.NIogBcGU9f-GdlN_BCbCJe8V42b0HLfAJRozdVKSAok";
    try {
      const { data } = await axios.post(post_url, newCandidateStatus, {
        "Content-type": "application/json; charset=UTF-8",
        "Access-Control-Allow-Origin": "*",
        headers: { Authorization: `Bearer ${token}` },
      });
      console.log("Added new product -", data);
      return data;
    } catch (error) {
      console.log("Entered actions catch block");
      console.log("error", error.response.data);
      return rejectWithValue(error.response);
    }
  }
);
export default addNewCandidateStatus;
